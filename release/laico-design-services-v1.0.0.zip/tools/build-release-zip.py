#!/usr/bin/env python3
"""Build the deployable ZIP that is attached to the GitHub Release.

The archive contains the whole static site plus docs, tools and design
references, at the archive root (unzip -> index.html, css/, js/, assets/ ...).

Excluded: .git, .qa (local QA tooling), archive/ (original laico.zip),
release/ (generated zips), .github/, caches and editor/OS files.

Run: python3 tools/build-release-zip.py
"""

import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "release" / "laico-design-services-v1.0.0.zip"
EXCLUDE_DIRS = {".git", ".qa", "archive", "release", ".github", "__pycache__", "node_modules", ".venv"}
EXCLUDE_FILES = {".gitignore", ".DS_Store", "Thumbs.db"}


def collect():
    items = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS and not d.startswith(".")]
        for name in sorted(filenames):
            if name in EXCLUDE_FILES or name.endswith((".pyc", ".log")):
                continue
            path = Path(dirpath) / name
            rel = path.relative_to(ROOT)
            if rel.parts[0] in EXCLUDE_DIRS:
                continue
            items.append((path, rel.as_posix()))
    return sorted(items, key=lambda x: x[1])


def main() -> int:
    items = collect()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path, rel in items:
            zf.write(path, rel)
    with zipfile.ZipFile(OUT) as zf:
        assert zf.testzip() is None, "corrupt ZIP"
        assert "services.html" in zf.namelist(), "services.html missing"
        assert "css/services.css" in zf.namelist(), "css/services.css missing"
    print(f"{OUT.relative_to(ROOT)}: {OUT.stat().st_size} bytes, {len(items)} files")
    return 0


if __name__ == "__main__":
    sys.exit(main())
