# CHANGELOG — LAICO DESIGN

## v2.0.1 — ۲۰۲۶‑۱۰‑۲۷ (بستهٔ دانلود تمیز)

- افزودن بستهٔ **فقط سایت** `release/laico-design-v2.0.1.zip` (حدود ۵ مگابایت)
  برای استقرار مستقیم روی وبسرور؛ شامل ۲۲ صفحهٔ HTML، CSS، JS، فونتها،
  تصاویر JPG+WebP، `404.html`, `robots.txt`, `sitemap.xml`,
  `site.webmanifest` و `README.md`.
- ابزار بازتولید بسته: `tools/build-site-zip.py`.
- راهنمای دانلود و الصاق Asset: [`release/README.md`](release/README.md).
- اصلاح لینکهای صفحهٔ ریلیز: لینک اصلی اکنون
  `https://codeload.github.com/amolnovin/licodesign/zip/refs/tags/v2.0.1-uiux`
  است (تأییدشده با HTTP 200).

هیچ تغییری در کد سایت نسبت به v2.0.0 اعمال نشد؛ این یک انتشار بستهای است.

## v2.0.0 — ۲۰۲۶‑۱۰‑۲۷ (ممیزی و رفع کامل UI/UX)

گزارش کامل: [`UIUX-REPORT.md`](UIUX-REPORT.md).

### UI
- اصلاح ۱۳ جفت رنگ کمکنتراست تا سطح WCAG 2.2 AA (≥ ۴٫۵:۱).
- حلقهٔ فوکوس ۳px سراسری، خوانایی هدر روی عکس، رفع نوار سفید skip link.
- قانون سراسری `[hidden]`, `scroll-padding-top`, احترام به `prefers-reduced-motion`.
- ۲۷ نسخهٔ WebP (‎−۶۰٪ حجم)، `<picture>`, ابعاد واقعی و `loading`/`fetchpriority`
  برای ۶۱/۶۱ تصویر.
- صفحهٔ ۴۰۴ اختصاصی، breadcrumb در ۲۰ صفحه، ۰ استایل درونخطی،
  ۰ خطای `html-validate`.

### UX
- فرمها: پیام صادقانه + ارسال واقعی از طریق واتساپ/تلفن/ایمیل +
  `formEndpoint` قابل تنظیم، رضایت، honeypot، انقضای ۳۰ روز، `aria-live`.
- ترجمهٔ کامل FA→EN (۳۸۸ رشته) در ۲۲/۲۲ صفحه.
- لینکدار شدن ۵ صفحهٔ یتیم، منوی والد، رفع قفل اسکرول منو، `<select>` بومی.
- ۲۲/۲۲ صفحه دارای یک `<h1>`؛ `alt`, ابعاد و `<label for>` اصلاح شدند.
- یکسانسازی تلفن/آدرس/ساعات/شبکههای اجتماعی در `js/config.js`.
- canonical, OG, twitter card, sitemap, robots, 404, JSON‑LD, web manifest.

### کیفیت
`audit.py --strict` = ۰ خطا/۰ هشدار · `uiux_audit.py` = ۱۰۰/۱۰۰ ·
`html-validate` = ۰ خطا · jsdom = ۲۵۱/۲۵۱ · Chromium = ۵۴۵/۵۴۵ + ۲۴۲/۲۴۲.

## v1.1.0 — ۲۰۲۶‑۱۰‑۲۶

بازطراحی `projects.html` بر اساس تصاویر مرجع (دسکتاپ + موبایل ریسپانسیو)،
فیلتر و جستجوی فعال.

## v1.0.0 — ۲۰۲۶‑۱۰‑۲۶

بازطراحی `services.html` بر اساس تصاویر مرجع (دسکتاپ + موبایل ریسپانسیو).

## پایه — ۲۰۲۶‑۱۰‑۲۶

استخراج `laico.zip` از Google Drive، مستندسازی، `tools/audit.py` و `REVIEW.md`.
